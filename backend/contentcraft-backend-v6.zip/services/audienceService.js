const AudiencePersona = require('../models/AudiencePersona');
const Content = require('../models/Content');
const Analytics = require('../models/Analytics');
const logger = require('../utils/logger');
const callModel = require('./callModel');

class AudienceService {

  // ── Sanitize AI persona output to match Mongoose schema exactly ──────────
  sanitizePersona(persona) {
    // Fix psychographics.personality — must be lowercase enum
    // e.g. "Innovator" → "innovator", "Early Adopter" → "early_adopter"
    if (persona.psychographics?.personality) {
      persona.psychographics.personality = persona.psychographics.personality
        .toLowerCase()
        .replace(/\s+/g, '_');
    }

    // Fix psychographics.interests — schema expects [{name: String, affinity: Number}]
    // AI sometimes returns plain strings ["Technology"]
    if (Array.isArray(persona.psychographics?.interests)) {
      persona.psychographics.interests = persona.psychographics.interests.map(item =>
        typeof item === 'string'
          ? { name: item, affinity: 50 }
          : { name: item.name || 'Unknown', affinity: item.affinity ?? 50 }
      );
    }

    // Fix contentPreferences.topics — schema expects [{name: String, interest: Number}]
    // AI sometimes returns plain strings ["Technology Trends"]
    if (Array.isArray(persona.contentPreferences?.topics)) {
      persona.contentPreferences.topics = persona.contentPreferences.topics.map(item =>
        typeof item === 'string'
          ? { name: item, interest: 50 }
          : { name: item.name || 'Unknown', interest: item.interest ?? 50 }
      );
    }

    // Fix contentPreferences.formats — schema [{ type: String }] = array of plain strings
    if (Array.isArray(persona.contentPreferences?.formats)) {
      persona.contentPreferences.formats = persona.contentPreferences.formats.map(item =>
        typeof item === "string" ? item : (item.type || item.format || "blog")
      );
    }

    // Fix behavior.preferredContentTypes — schema [{ type: String }] = array of plain strings
    if (Array.isArray(persona.behavior?.preferredContentTypes)) {
      persona.behavior.preferredContentTypes = persona.behavior.preferredContentTypes.map(item =>
        typeof item === "string" ? item : (item.type || item.contentType || "blog")
      );
    }

    // Fix contentPreferences.length — must match enum: short|medium|long|mixed
    const validLengths = ['short', 'medium', 'long', 'mixed'];
    if (persona.contentPreferences?.length &&
        !validLengths.includes(persona.contentPreferences.length)) {
      persona.contentPreferences.length = 'medium';
    }

    // Fix purchaseIntent.stage — must match enum
    const validStages = ['awareness', 'consideration', 'decision', 'purchase', 'loyalty'];
    if (persona.purchaseIntent?.stage &&
        !validStages.includes(persona.purchaseIntent.stage)) {
      persona.purchaseIntent.stage = 'consideration';
    }

    // Fix sourcePlatforms — must match enum
    const validPlatforms = ['twitter', 'linkedin', 'instagram', 'facebook', 'tiktok', 'youtube'];
    if (Array.isArray(persona.sourcePlatforms)) {
      persona.sourcePlatforms = persona.sourcePlatforms.filter(sp =>
        validPlatforms.includes(sp.platform)
      );
    }

    return persona;
  }

  // Generate audience personas from data
  async generatePersonas(userId, platformData = {}) {
    try {
      const contentData = await Content.find({
        user: userId,
        status: 'published',
      })
        .sort({ createdAt: -1 })
        .limit(50)
        .select('performance platform type tags tone');

      const analyticsData = await Analytics.find({ user: userId })
        .sort({ date: -1 })
        .limit(30);

      const prompt = `Analyze this content performance data and create 3-5 detailed audience personas.

Content Performance:
${JSON.stringify(contentData.map(c => ({
  platform: c.platform,
  type: c.type,
  tags: c.tags,
  engagement: c.performance,
})))}

Platform Data:
${JSON.stringify(platformData)}

For each persona, provide EXACTLY this structure:
{
  "name": "Tech-Savvy Startup Founder",
  "description": "brief overview",
  "demographics": {
    "ageRange": { "min": 25, "max": 35 },
    "gender": "male",
    "locations": [{ "country": "US", "percentage": 60 }],
    "occupation": ["Software Engineer"],
    "industries": ["Technology"],
    "income": { "range": "$50k-$100k", "currency": "USD" }
  },
  "psychographics": {
    "interests": [{ "name": "Technology", "affinity": 85 }],
    "values": ["innovation", "efficiency"],
    "personality": "innovator",
    "goals": ["grow business", "save time"],
    "challenges": ["lack of resources"]
  },
  "behavior": {
    "activeHours": [{ "day": "Monday", "hours": [9, 10, 20] }],
    "preferredContentTypes": [{ "type": "blog", "percentage": 40 }],
    "engagementPatterns": { "likesFrequency": "high", "commentFrequency": "medium", "shareFrequency": "low" },
    "deviceUsage": { "mobile": 60, "desktop": 35, "tablet": 5 }
  },
  "painPoints": [{ "description": "not enough time", "severity": 8 }],
  "contentPreferences": {
    "topics": [{ "name": "AI Tools", "interest": 90 }],
    "formats": [{ "type": "video", "preference": 80 }],
    "tone": ["professional", "friendly"],
    "length": "medium"
  },
  "purchaseIntent": { "score": 75, "stage": "consideration", "priceSensitivity": 40 }
}

STRICT RULES:
- personality must be exactly one of: innovator, early_adopter, early_majority, late_majority, laggard
- interests must be array of objects with "name" and "affinity" fields — NOT plain strings
- topics must be array of objects with "name" and "interest" fields — NOT plain strings
- formats must be array of objects with "type" and "preference" fields — NOT plain strings
- length must be exactly one of: short, medium, long, mixed
- stage must be exactly one of: awareness, consideration, decision, purchase, loyalty

Respond with a JSON array of personas only. No extra text.`;

      const responseText = await callModel(prompt);

      let personas;
      try {
        const jsonMatch = responseText.match(/\[[\s\S]*\]/);
        personas = JSON.parse(jsonMatch ? jsonMatch[0] : responseText);
      } catch (parseError) {
        logger.error('Persona parse error:', parseError);
        personas = this.generateDefaultPersonas();
      }

      // Sanitize each persona before saving to DB
      const savedPersonas = [];
      for (const personaData of personas) {
        try {
          const sanitized = this.sanitizePersona(personaData);
          const persona = await AudiencePersona.create({
            user: userId,
            ...sanitized,
            isAutoGenerated: true,
            lastAnalyzed: new Date(),
          });
          savedPersonas.push(persona);
        } catch (personaError) {
          // Log individual persona error but continue saving others
          logger.error('Single persona save error:', personaError.message);
        }
      }

      // If all personas failed, use defaults
      if (savedPersonas.length === 0) {
        const defaults = this.generateDefaultPersonas();
        for (const personaData of defaults) {
          const sanitized = this.sanitizePersona(personaData);
          const persona = await AudiencePersona.create({
            user: userId,
            ...sanitized,
            isAutoGenerated: true,
            lastAnalyzed: new Date(),
          });
          savedPersonas.push(persona);
        }
      }

      return {
        success: true,
        personas: savedPersonas,
        count: savedPersonas.length,
      };
    } catch (error) {
      logger.error('Generate personas error:', error);
      return {
        success: false,
        error: error.message,
      };
    }
  }

  // Analyze audience behavior patterns
  async analyzeBehaviorPatterns(userId, personaId = null) {
    try {
      const query = { user: userId };
      if (personaId) query._id = personaId;

      const personas = await AudiencePersona.find(query);

      const analysis = {
        peakActivityTimes: this.calculatePeakTimes(personas),
        contentPreferences: this.aggregateContentPreferences(personas),
        engagementPatterns: this.aggregateEngagementPatterns(personas),
        deviceBreakdown: this.calculateDeviceBreakdown(personas),
        geographicDistribution: this.aggregateGeography(personas),
      };

      return {
        success: true,
        analysis,
        personas: personas.map(p => ({
          id: p._id,
          name: p.name,
          segmentSize: p.segmentSize,
        })),
      };
    } catch (error) {
      logger.error('Behavior analysis error:', error);
      return { success: false, error: error.message };
    }
  }

  // Identify pain points
  async identifyPainPoints(userId) {
    try {
      const personas = await AudiencePersona.find({ user: userId });

      const allPainPoints = [];
      for (const persona of personas) {
        for (const painPoint of persona.painPoints) {
          allPainPoints.push({
            persona: persona.name,
            ...painPoint.toObject(),
          });
        }
      }

      const grouped = this.groupPainPoints(allPainPoints);

      return {
        success: true,
        painPoints: grouped,
        topPainPoints: grouped.slice(0, 5),
        contentOpportunities: this.suggestPainPointContent(grouped),
      };
    } catch (error) {
      logger.error('Pain points error:', error);
      return { success: false, error: error.message };
    }
  }

  // Find content gaps
  async findContentGaps(userId) {
    try {
      const personas = await AudiencePersona.find({ user: userId });
      const existingContent = await Content.find({
        user: userId,
        status: { $in: ['published', 'scheduled'] },
      }).select('tags type title');

      const prompt = `Analyze audience interests and existing content to identify content gaps.

Audience Interests:
${JSON.stringify(personas.flatMap(p => p.contentPreferences.topics))}

Existing Content Topics:
${JSON.stringify(existingContent.map(c => ({ title: c.title, tags: c.tags, type: c.type })))}

Respond in JSON format:
{
  "gaps": [
    {
      "topic": "topic name",
      "demand": 75,
      "supply": 20,
      "opportunity": 85,
      "recommendedFormat": "blog",
      "contentIdeas": ["idea1", "idea2"]
    }
  ],
  "prioritizedGaps": ["gap1", "gap2"],
  "recommendedContentCalendar": [{ "topic": "topic", "priority": "high", "timeline": "1 week" }]
}

Respond with ONLY the JSON object, no extra text.`;

      const responseText = await callModel(prompt);

      let gaps;
      try {
        const jsonMatch = responseText.match(/\{[\s\S]*\}/);
        gaps = JSON.parse(jsonMatch ? jsonMatch[0] : responseText);
      } catch {
        gaps = { gaps: [], prioritizedGaps: [], recommendedContentCalendar: [] };
      }

      return { success: true, ...gaps };
    } catch (error) {
      logger.error('Content gaps error:', error);
      return { success: false, error: error.message };
    }
  }

  // Get demographic breakdown
  async getDemographics(userId) {
    try {
      const personas = await AudiencePersona.find({ user: userId });

      const demographics = {
        ageDistribution: this.calculateAgeDistribution(personas),
        genderDistribution: this.calculateGenderDistribution(personas),
        locationDistribution: this.calculateLocationDistribution(personas),
        occupationDistribution: this.calculateOccupationDistribution(personas),
        incomeDistribution: this.calculateIncomeDistribution(personas),
        educationDistribution: this.calculateEducationDistribution(personas),
      };

      return {
        success: true,
        demographics,
        totalAudience: personas.reduce((sum, p) => sum + (p.segmentSize?.absolute || 0), 0),
      };
    } catch (error) {
      logger.error('Demographics error:', error);
      return { success: false, error: error.message };
    }
  }

  // Get personality profile
  async getPersonalityProfile(userId) {
    try {
      const personas = await AudiencePersona.find({ user: userId });

      const personalityTypes = {
        innovator: 0,
        early_adopter: 0,
        early_majority: 0,
        late_majority: 0,
        laggard: 0,
      };

      for (const persona of personas) {
        const type = persona.psychographics?.personality;
        if (type && personalityTypes[type] !== undefined) {
          personalityTypes[type] += persona.segmentSize?.percentage || 0;
        }
      }

      return {
        success: true,
        personalityProfile: personalityTypes,
        dominantType: Object.entries(personalityTypes).sort((a, b) => b[1] - a[1])[0][0],
        interpretation: this.interpretPersonalityProfile(personalityTypes),
      };
    } catch (error) {
      logger.error('Personality profile error:', error);
      return { success: false, error: error.message };
    }
  }

  // Create audience segments
  async createSegments(userId, segmentCriteria) {
    try {
      const personas = await AudiencePersona.find({ user: userId });
      const segments = [];

      for (const criteria of segmentCriteria) {
        const matchingPersonas = personas.filter(p => {
          if (criteria.ageRange) {
            const age = p.demographics?.ageRange;
            if (age && (age.min > criteria.ageRange.max || age.max < criteria.ageRange.min)) return false;
          }
          if (criteria.interests?.length > 0) {
            const interests = p.psychographics?.interests?.map(i => i.name) || [];
            if (!criteria.interests.some(i => interests.includes(i))) return false;
          }
          if (criteria.locations?.length > 0) {
            const locations = p.demographics?.locations?.map(l => l.country) || [];
            if (!criteria.locations.some(l => locations.includes(l))) return false;
          }
          return true;
        });

        if (matchingPersonas.length > 0) {
          segments.push({
            name: criteria.name,
            criteria,
            personas: matchingPersonas.map(p => p._id),
            estimatedSize: matchingPersonas.reduce((sum, p) => sum + (p.segmentSize?.absolute || 0), 0),
            percentage: matchingPersonas.reduce((sum, p) => sum + (p.segmentSize?.percentage || 0), 0),
          });
        }
      }

      return { success: true, segments, count: segments.length };
    } catch (error) {
      logger.error('Create segments error:', error);
      return { success: false, error: error.message };
    }
  }

  // Get purchase intent scores
  async getPurchaseIntent(userId) {
    try {
      const personas = await AudiencePersona.find({ user: userId });

      const intentDistribution = {
        awareness: [], consideration: [], decision: [], purchase: [], loyalty: [],
      };

      let totalScore = 0;
      let totalSize = 0;

      for (const persona of personas) {
        const intent = persona.purchaseIntent;
        if (intent) {
          intentDistribution[intent.stage]?.push({
            persona: persona.name,
            score: intent.score,
            size: persona.segmentSize?.percentage || 0,
          });
          totalScore += intent.score * (persona.segmentSize?.percentage || 0);
          totalSize += persona.segmentSize?.percentage || 0;
        }
      }

      const averageIntent = totalSize > 0 ? totalScore / totalSize : 0;

      return {
        success: true,
        intentDistribution,
        averageIntentScore: averageIntent.toFixed(1),
        readyToBuy: intentDistribution.decision.length + intentDistribution.purchase.length,
        needNurturing: intentDistribution.awareness.length + intentDistribution.consideration.length,
      };
    } catch (error) {
      logger.error('Purchase intent error:', error);
      return { success: false, error: error.message };
    }
  }

  // Track audience evolution
  async trackEvolution(userId, months = 6) {
    try {
      const currentPersonas = await AudiencePersona.find({ user: userId });

      const evolution = {
        period: `${months} months`,
        currentSnapshot: {
          totalPersonas: currentPersonas.length,
          dominantInterests: this.getDominantInterests(currentPersonas),
          growingSegments: this.identifyGrowingSegments(currentPersonas),
          decliningSegments: this.identifyDecliningSegments(currentPersonas),
        },
        trends: [
          'Increased interest in AI-related content',
          'Shift toward video content consumption',
          'Growing mobile audience',
        ],
        predictions: [
          'AI and automation topics will continue growing',
          'Short-form video preference will increase',
          'International audience will expand',
        ],
      };

      return { success: true, evolution };
    } catch (error) {
      logger.error('Track evolution error:', error);
      return { success: false, error: error.message };
    }
  }

  // ── Helper methods ────────────────────────────────────────────────────────

  calculatePeakTimes(personas) {
    const hourActivity = Array(24).fill(0);
    for (const persona of personas) {
      for (const dayData of persona.behavior?.activeHours || []) {
        for (const hour of dayData.hours || []) {
          hourActivity[hour] += persona.segmentSize?.percentage || 1;
        }
      }
    }
    return hourActivity
      .map((activity, hour) => ({ hour, activity }))
      .sort((a, b) => b.activity - a.activity)
      .slice(0, 5);
  }

  aggregateContentPreferences(personas) {
    const preferences = {};
    for (const persona of personas) {
      for (const pref of persona.contentPreferences?.topics || []) {
        const name = typeof pref === 'object' ? pref.name : pref;
        const interest = typeof pref === 'object' ? pref.interest : 50;
        preferences[name] = (preferences[name] || 0) + interest;
      }
    }
    return Object.entries(preferences)
      .map(([name, interest]) => ({ name, interest: interest / personas.length }))
      .sort((a, b) => b.interest - a.interest);
  }

  aggregateEngagementPatterns(personas) {
    const patterns = {
      likesFrequency: { high: 0, medium: 0, low: 0 },
      commentFrequency: { high: 0, medium: 0, low: 0 },
      shareFrequency: { high: 0, medium: 0, low: 0 },
    };
    for (const persona of personas) {
      const engagement = persona.behavior?.engagementPatterns;
      if (engagement) {
        if (patterns.likesFrequency[engagement.likesFrequency] !== undefined)
          patterns.likesFrequency[engagement.likesFrequency]++;
        if (patterns.commentFrequency[engagement.commentFrequency] !== undefined)
          patterns.commentFrequency[engagement.commentFrequency]++;
        if (patterns.shareFrequency[engagement.shareFrequency] !== undefined)
          patterns.shareFrequency[engagement.shareFrequency]++;
      }
    }
    return patterns;
  }

  calculateDeviceBreakdown(personas) {
    const breakdown = { mobile: 0, desktop: 0, tablet: 0 };
    for (const persona of personas) {
      const devices = persona.behavior?.deviceUsage;
      if (devices) {
        breakdown.mobile += devices.mobile * (persona.segmentSize?.percentage || 0) / 100;
        breakdown.desktop += devices.desktop * (persona.segmentSize?.percentage || 0) / 100;
        breakdown.tablet += devices.tablet * (persona.segmentSize?.percentage || 0) / 100;
      }
    }
    return breakdown;
  }

  aggregateGeography(personas) {
    const locations = {};
    for (const persona of personas) {
      for (const loc of persona.demographics?.locations || []) {
        locations[loc.country] = (locations[loc.country] || 0) + loc.percentage;
      }
    }
    return Object.entries(locations)
      .map(([country, percentage]) => ({ country, percentage }))
      .sort((a, b) => b.percentage - a.percentage);
  }

  groupPainPoints(painPoints) {
    const grouped = {};
    for (const pp of painPoints) {
      const key = pp.description.toLowerCase();
      if (!grouped[key]) grouped[key] = { ...pp, count: 0, personas: [] };
      grouped[key].count++;
      grouped[key].personas.push(pp.persona);
    }
    return Object.values(grouped)
      .sort((a, b) => b.severity * b.count - a.severity * a.count);
  }

  suggestPainPointContent(painPoints) {
    return painPoints.slice(0, 5).map(pp => ({
      painPoint: pp.description,
      contentIdeas: [
        `How to overcome ${pp.description.toLowerCase()}`,
        `5 solutions for ${pp.description.toLowerCase()}`,
        `The ultimate guide to solving ${pp.description.toLowerCase()}`,
      ],
      targetPersonas: pp.personas,
    }));
  }

  calculateAgeDistribution(personas) {
    const distribution = {};
    for (const persona of personas) {
      const age = persona.demographics?.ageRange;
      if (age) {
        const key = `${age.min}-${age.max}`;
        distribution[key] = (distribution[key] || 0) + (persona.segmentSize?.percentage || 0);
      }
    }
    return distribution;
  }

  calculateGenderDistribution(personas) {
    const distribution = { male: 0, female: 0, 'non-binary': 0, unknown: 0 };
    for (const persona of personas) {
      const gender = persona.demographics?.gender;
      if (gender && distribution[gender] !== undefined) {
        distribution[gender] += persona.segmentSize?.percentage || 0;
      }
    }
    return distribution;
  }

  calculateLocationDistribution(personas) {
    return this.aggregateGeography(personas);
  }

  calculateOccupationDistribution(personas) {
    const distribution = {};
    for (const persona of personas) {
      for (const occ of persona.demographics?.occupation || []) {
        distribution[occ] = (distribution[occ] || 0) + (persona.segmentSize?.percentage || 0);
      }
    }
    return distribution;
  }

  calculateIncomeDistribution(personas) {
    const distribution = {};
    for (const persona of personas) {
      const income = persona.demographics?.income?.range;
      if (income) {
        distribution[income] = (distribution[income] || 0) + (persona.segmentSize?.percentage || 0);
      }
    }
    return distribution;
  }

  calculateEducationDistribution(personas) {
    const distribution = {};
    for (const persona of personas) {
      for (const edu of persona.demographics?.education || []) {
        distribution[edu] = (distribution[edu] || 0) + (persona.segmentSize?.percentage || 0);
      }
    }
    return distribution;
  }

  interpretPersonalityProfile(profile) {
    const dominant = Object.entries(profile).sort((a, b) => b[1] - a[1])[0];
    const interpretations = {
      innovator: 'Your audience is eager to try new things and be first. Focus on cutting-edge content.',
      early_adopter: 'Your audience is trend-aware and influential. Leverage emerging trends.',
      early_majority: 'Your audience values proven solutions. Use testimonials and case studies.',
      late_majority: 'Your audience is cautious. Emphasize reliability and support.',
      laggard: 'Your audience is traditional. Focus on established methods and gradual change.',
    };
    return interpretations[dominant[0]] || 'Mixed audience - diversify content approach.';
  }

  getDominantInterests(personas) {
    const interests = {};
    for (const persona of personas) {
      for (const interest of persona.psychographics?.interests || []) {
        const name = typeof interest === 'object' ? interest.name : interest;
        const affinity = typeof interest === 'object' ? interest.affinity : 50;
        interests[name] = (interests[name] || 0) + affinity;
      }
    }
    return Object.entries(interests)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([name]) => name);
  }

  identifyGrowingSegments(personas) {
    return personas
      .filter(p => p.performance?.avgEngagement > 5)
      .map(p => p.name);
  }

  identifyDecliningSegments(personas) {
    return [];
  }

  generateDefaultPersonas() {
    return [
      {
        name: 'Tech-Savvy Professional',
        description: 'Early adopter of technology, values efficiency and innovation',
        demographics: {
          ageRange: { min: 25, max: 40 },
          gender: 'unknown',
          locations: [{ country: 'US', percentage: 50 }],
        },
        psychographics: {
          interests: [{ name: 'Technology', affinity: 90 }],
          values: ['innovation', 'efficiency'],
          personality: 'innovator',
          goals: ['stay ahead of trends'],
          challenges: ['information overload'],
        },
        behavior: {
          activeHours: [{ day: 'Monday', hours: [9, 10, 20] }],
          preferredContentTypes: ['blog'],
          engagementPatterns: { likesFrequency: 'high', commentFrequency: 'medium', shareFrequency: 'low' },
          deviceUsage: { mobile: 60, desktop: 35, tablet: 5 },
        },
        painPoints: [{ description: 'Too much noise, not enough signal', severity: 7 }],
        contentPreferences: {
          topics: [{ name: 'Technology', interest: 90 }],
          formats: ['video'],
          tone: ['professional'],
          length: 'medium',
        },
        purchaseIntent: { score: 70, stage: 'consideration', priceSensitivity: 40 },
      },
    ];
  }
}

module.exports = new AudienceService();